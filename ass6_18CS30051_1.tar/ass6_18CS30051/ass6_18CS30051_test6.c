int printi(int);

int main(){
    int a = 0;
    printi(a);
}